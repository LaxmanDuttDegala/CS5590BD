package com.umkc.fileupload;

import java.io.File;
import java.io.FileInputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.tika.Tika;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    public void fileupload(View view) {
    	//Toast.makeText(getApplicationContext(), "File Upload", Toast.LENGTH_SHORT).show();
    	    	
    	File sdcard = Environment.getExternalStorageDirectory();
		File f = new File(sdcard, "sensor_laxman1.txt");
		Toast.makeText(getApplicationContext(), f.getPath().toString(), Toast.LENGTH_SHORT).show();
		String url = "http://134.193.136.147:8080/HbaseWS_laxman/jaxrs/generic/hbaseInsert/Laxman_Table/-home-cloudera-Downloads-sensor_laxman1.txt" + "/GeoLocation:Date:Accelerometer:Humidity:Temp";
		
	//	new HTTPAsyncTask().execute("http://google.com");
		
    	Gson gson = new Gson();
    	FileInputStream fileInputStream = null;
		File file = new File("D:\\.png");
		byte[] bFile = new byte[(int) file.length()];
		try {
			// convert file into array of bytes
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bFile);
			fileInputStream.close();
			System.out.println(bFile.length);
			byte[] encoded = Base64.encodeBase64(bFile);
			String encodedFile = new String(encoded);
			
			//Tika tika = new Tika();
			//String mimetype = tika.detect(encoded);	
		} catch(Exception e) {
			System.out.println("MainActivity.fileupload()");
		}
	}
    private class HTTPAsyncTask extends AsyncTask<String, Void, String> {

		

		@Override
		protected String doInBackground(String... params) {
			
			HttpClient h = new DefaultHttpClient();
			HttpGet get = new HttpGet("");
			
			return null;
		}
    	
    }
}
