package com.umkc.fileupload;

public class FilePojo {
	String data;
	String filetype;
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
}
